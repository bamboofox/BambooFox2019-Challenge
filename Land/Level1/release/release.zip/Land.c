#include "Land.h"

//----do not modify above----

rectangle find_rectangle(){
	rectangle answer;
	long long query = area(0, 0, 1, 1);
	answer.a=0,answer.b=0,answer.c=1,answer.d=1;
	return answer;
}
